#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Hello World!\n\n");
    
    printf("   /|\n");
    printf("  / |\n");
    printf(" /  |\n");
    printf("/___|\n");

    /*
    char characterName[] = "John";
    int characerAge = 35;
    double gpa = 37.7;
    char grade = 'A';
    double dPi = 3.14159;
    float fPi = 3.141592653589793238;

    printf("There once was a man named %s\n", characterName);
    printf("he was %d years old, not %.2f.\n", characerAge, gpa);
    printf("He really liked the name %s\n", characterName);
    printf("but did not liked being %d.\n", characerAge);
    printf("My favorite double %s is %.2f\n", "number", dPi);
    printf("My favorite float %s is %.4f\n", "number", fPi);
    printf("My favorite %s is %c.\n", "character", grade);
    printf("5.0 x 4.5 = %f.\n", 5.0 * 4.5);
    printf("5-4.5 (integer-decimal gives a floating point) = %f.\n", 5-4.5);
    printf("5-4 (integer-integer gives integer)= %f (float !working!\n", 5-4);
    printf("5-4 (integer-integer gives integer)= %d.\n\n", 5-4);  
    */

    return 0;
}
